from contextlib import asynccontextmanager
from typing import List, Annotated, Optional
from datetime import datetime
import hashlib
import secrets

from fastapi import Depends, FastAPI, HTTPException, status, Query
from fastapi.security import HTTPBasic, HTTPBasicCredentials, OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import func


import models
import schemas
from database import SessionLocal, engine
from db_init import init_db

from datetime import datetime, timedelta
import hashlib
import secrets
import binascii
from jose import JWTError, jwt
from datetime import datetime, timedelta, date
from fastapi.security import OAuth2PasswordBearer
from fastapi.responses import JSONResponse



SECRET_KEY = "your-secret-key-here"  # Change this to a strong random key in production!
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Lifespan handler
@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Initializing database...")
    init_db()
    yield
    print("Shutting down...")

app = FastAPI(lifespan=lifespan)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

security = HTTPBasic()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Database dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

db_dependency = Annotated[Session, Depends(get_db)]
credentials_dependency = Annotated[HTTPBasicCredentials, Depends(security)]

# Authentication Utilities
def hash_password(password: str, salt: str = None) -> tuple[str, str]:
    """Secure password hashing using PBKDF2-HMAC-SHA256"""
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        10  # Number of iterations
    )
    hashed = binascii.hexlify(dk).decode()
    return hashed, salt

def verify_password(plain_password: str, hashed_password: str, salt: str) -> bool:
    """Verify password against stored hash"""
    new_hash, _ = hash_password(plain_password, salt)
    return secrets.compare_digest(new_hash, hashed_password)

def create_access_token(data: dict, expires_delta: timedelta = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.PyJWTError:
        return None

def authenticate_user(db: Session, username: str, password: str):
    """Authenticate user by username/email and password"""
    user = db.query(models.User).filter(models.User.username == username).first()
    if not user:
        user = db.query(models.User).filter(models.User.email == username).first()
        if not user:
            return None
    
    if not user.verify_password(password):
        return None
    return user

def get_current_user(
    db: db_dependency,
    credentials: credentials_dependency
):
    """Dependency to get current authenticated user"""
    user = authenticate_user(db, credentials.username, credentials.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Basic"},
        )
    return user

current_user_dependency = Annotated[models.User, Depends(get_current_user)]

@app.get("/health")
async def health_check():
    return {"status": "ok", "message": "Server is running"}

# Authentication Endpoints

# endpoint for token verification
@app.get("/verify-token")
async def verify_token(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        user = db.query(models.User).filter(models.User.username == username).first()
        if not user:
            raise HTTPException(status_code=401, detail="Invalid user")
        return {"username": username}
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Updated /token endpoint to include username
@app.post("/token")
async def login_for_access_token(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=401,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={
            "sub": user.username,
        },
        expires_delta=access_token_expires
    )
    
    return { 
        "access_token": access_token,
        "token_type": "bearer",
        "username": user.username,
    }

@app.post("/register/", response_model=schemas.UserPublic)
def register_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    print("\n=== Registration Attempt ===")
    print(f"Username: {user.username}")
    print(f"Email: {user.email}")
    
    try:
        # Check for existing username
        existing_user = db.query(models.User).filter(
            models.User.username == user.username
        ).first()
        if existing_user:
            print("❌ Username already exists")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username already registered"
            )

        # Check for existing email
        existing_email = db.query(models.User).filter(
            models.User.email == user.email
        ).first()
        if existing_email:
            print("❌ Email already exists")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already registered"
            )

        # Create user - let the model handle password hashing
        print("Creating new user...")
        db_user = models.User(
            username=user.username,
            email=user.email,
            password=user.password  # Plain password
        )
        
        db.add(db_user)
        db.flush()  # Test if we can persist without full commit
        print("User flushed successfully")
        
        db.commit()
        print("✅ User committed to database")
        db.refresh(db_user)
        
        # Verify what was actually stored
        stored_user = db.query(models.User).filter(
            models.User.username == user.username
        ).first()
        print("Stored user details:")
        print(f"Username: {stored_user.username}")
        print(f"Email: {stored_user.email}")
        print(f"Salt: {stored_user.salt}")
        print(f"Password hash: {stored_user.hashed_password}")
        
        return db_user
        
    except Exception as e:
        db.rollback()
        print(f"❌ Registration failed: {str(e)}")
        print(f"Error type: {type(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

# User Endpoints
@app.get("/users/me/", response_model=schemas.UserPublic)
def read_current_user(current_user: current_user_dependency):
    """Get current user details"""
    return current_user

@app.get("/users/{user_id}/booked-flights")
def get_user_booked_flights(user_id: int, db: db_dependency):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user.booked_flights.split(",") if user.booked_flights else []

# Flight Endpoints
@app.post("/flights", response_model=schemas.FlightPublic)
def create_flight(
    flight: schemas.FlightCreate,
    db: Session = Depends(get_db),
    # current_user: models.User = Depends(get_current_user)
):
    try:
        # Validate airports exist
        departure_airport = db.query(models.Airport).filter_by(code=flight.departure_code).first()
        destination_airport = db.query(models.Airport).filter_by(code=flight.destination_code).first()
        
        if not departure_airport or not destination_airport:
            raise HTTPException(
                status_code=400,
                detail="Invalid airport code(s) provided"
            )
        
        # Validate dates
        if flight.arrival_time <= flight.departure_time:
            raise HTTPException(
                status_code=400,
                detail="Arrival time must be after departure time"
            )
        
        db_flight = models.Flight(
            **flight.model_dump(exclude={"departure_code", "destination_code"}),
            departure_code=flight.departure_code.upper(),
            destination_code=flight.destination_code.upper(),
            # user_id=current_user.id
        )
        
        db.add(db_flight)
        db.commit()
        db.refresh(db_flight)
        return db_flight
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=500,
            detail=f"Failed to create flight: {str(e)}"
        )


@app.get("/flights", response_model=List[schemas.FlightWithDetails])
def get_flights(
    db: db_dependency,
    departure_code: Optional[str] = None,
    destination_code: Optional[str] = None,
    departure_date: Optional[date] = None,
    skip: int = 0,
    limit: int = 100
):
    """Get flights with optional filters"""
    query = db.query(models.Flight).options(
        joinedload(models.Flight.airline),
        joinedload(models.Flight.departure_airport).joinedload(models.Airport.country),
        joinedload(models.Flight.destination_airport).joinedload(models.Airport.country)
    )

    if departure_code:
        query = query.filter(models.Flight.departure_code == departure_code)
    if destination_code:
        query = query.filter(models.Flight.destination_code == destination_code)
    if departure_date:
        query = query.filter(func.date(models.Flight.departure_time) == departure_date)

    flights = query.offset(skip).limit(limit).all()
    return flights


@app.get("/flights/search", response_model=List[schemas.FlightWithDetails])
def search_flights(
    departure_code: Optional[str] = Query(None, min_length=3, max_length=3),
    destination_code: Optional[str] = Query(None, min_length=3, max_length=3),
    departure_date: Optional[str] = Query(None),  # Accept as string for flexibility
    db: Session = Depends(get_db)
):
    try:
        query = db.query(models.Flight).options(
            joinedload(models.Flight.airline),
            joinedload(models.Flight.departure_airport).joinedload(models.Airport.country),
            joinedload(models.Flight.destination_airport).joinedload(models.Airport.country)
        )

        if departure_code and len(departure_code.strip()) >= 3:
            query = query.filter(models.Flight.departure_code == departure_code.upper())

        if destination_code and len(destination_code.strip()) >= 3:
            query = query.filter(models.Flight.destination_code == destination_code.upper())

        if departure_date:
            # Accept both 'YYYY-MM-DD' and 'YYYY-MM-DDTHH:MM'
            try:
                if 'T' in departure_date:
                    departure_date_obj = datetime.strptime(departure_date[:10], "%Y-%m-%d").date()
                else:
                    departure_date_obj = datetime.strptime(departure_date, "%Y-%m-%d").date()
                query = query.filter(func.date(models.Flight.departure_time) == departure_date_obj)
            except Exception:
                raise HTTPException(
                    status_code=422,
                    detail="Invalid date format. Use YYYY-MM-DD."
                )

        flights = query.all()

        if not flights:
            return JSONResponse(
                status_code=404,
                content={"detail": "No flights found"}
            )

        return flights

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# Passenger Endpoints
@app.post("/passengers/", response_model=schemas.PassengerPublic)
def create_passenger(
    db: db_dependency,
    passenger: schemas.PassengerCreate
):
    """Create a new passenger"""
    db_passenger = models.Passenger(**passenger.model_dump())
    db.add(db_passenger)
    db.commit()
    db.refresh(db_passenger)
    return db_passenger

@app.get("/passengers/", response_model=List[schemas.PassengerPublic])
def read_passengers(
    db: db_dependency,
    skip: int = 0,
    limit: int = 100
):
    """Get list of passengers"""
    passengers = db.query(models.Passenger).offset(skip).limit(limit).all()
    return passengers

# Reservation Endpoints
@app.post("/reservations/", response_model=schemas.ReservationPublic)
def create_reservation(
    db: db_dependency,
    reservation: schemas.ReservationCreate
):
    # Check if flight exists
    db_flight = db.query(models.Flight).filter(
        models.Flight.id == reservation.flight_id
    ).first()
    if not db_flight:
        raise HTTPException(status_code=404, detail="Flight not found")

    # Check if user exists by username
    db_user = db.query(models.User).filter(
        models.User.username == reservation.username
    ).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")

    seat_number = reservation.seat_number or "AUTO"

    db_reservation = models.Reservation(
        user_id=db_user.id,
        flight_id=reservation.flight_id,
        seat_number=seat_number,
        status=reservation.status or "Pending",
        booking_agent_id=reservation.booking_agent_id
    )
    db.add(db_reservation)
    db.commit()
    db.refresh(db_reservation)
    return db_reservation

# Ticket Endpoints
@app.post("/tickets/", response_model=schemas.TicketPublic)
def create_ticket(
    db: db_dependency,
    ticket: schemas.TicketCreate
):
    """Create a new ticket"""
    # Check reservation exists
    reservation = db.query(models.Reservation).filter(
        models.Reservation.id == ticket.reservation_id
    ).first()
    if not reservation:
        raise HTTPException(status_code=404, detail="Reservation not found")
    
    db_ticket = models.Ticket(**ticket.model_dump())
    db.add(db_ticket)
    db.commit()
    db.refresh(db_ticket)
    return db_ticket

# Payment Endpoints
@app.post("/payments/", response_model=schemas.PaymentPublic)
def create_payment(
    db: db_dependency,
    payment: schemas.PaymentCreate
):
    """Create a new payment"""
    db_payment = models.Payment(**payment.model_dump())
    db.add(db_payment)
    db.commit()
    db.refresh(db_payment)
    return db_payment

# Airport Endpoints
@app.get("/airports/", response_model=List[schemas.AirportWithCountry])
def get_airports_with_countries(
    db: db_dependency,
    skip: int = 0,
    limit: int = 100
):
    """Get list of airports with country information"""
    airports = db.query(models.Airport).options(
        joinedload(models.Airport.country)
    ).offset(skip).limit(limit).all()
    return airports


# ------------------- Country Endpoints -------------------
@app.get("/countries/", response_model=List[schemas.CountryPublic])
def get_countries(
    db: db_dependency,
    skip: int = 0,
    limit: int = 100
):
    """Get list of countries"""
    countries = db.query(models.Country).offset(skip).limit(limit).all()
    return countries

@app.post("/countries/", response_model=schemas.CountryPublic)
def create_country(
    country: schemas.CountryBase,
    db: db_dependency
):
    """Create a new country"""
    db_country = models.Country(**country.model_dump())
    db.add(db_country)
    db.commit()
    db.refresh(db_country)
    return db_country

@app.put("/countries/{code}", response_model=schemas.CountryPublic)
def update_country(
    code: str,
    country: schemas.CountryBase,
    db: db_dependency
):
    """Update a country by code"""
    db_country = db.query(models.Country).filter(models.Country.code == code).first()
    if not db_country:
        raise HTTPException(status_code=404, detail="Country not found")
    for key, value in country.model_dump().items():
        setattr(db_country, key, value)
    db.commit()
    db.refresh(db_country)
    return db_country

@app.delete("/countries/{code}")
def delete_country(
    code: str,
    db: db_dependency
):
    """Delete a country by code"""
    db_country = db.query(models.Country).filter(models.Country.code == code).first()
    if not db_country:
        raise HTTPException(status_code=404, detail="Country not found")
    db.delete(db_country)
    db.commit()
    return {"detail": "Country deleted"}

# ------------------- Airport Endpoints -------------------
@app.post("/airports/", response_model=schemas.AirportPublic)
def create_airport(
    airport: schemas.AirportBase,
    db: db_dependency
):
    """Create a new airport"""
    db_airport = models.Airport(**airport.model_dump())
    db.add(db_airport)
    db.commit()
    db.refresh(db_airport)
    return db_airport

@app.put("/airports/{code}", response_model=schemas.AirportPublic)
def update_airport(
    code: str,
    airport: schemas.AirportBase,
    db: db_dependency
):
    """Update an airport by code"""
    db_airport = db.query(models.Airport).filter(models.Airport.code == code).first()
    if not db_airport:
        raise HTTPException(status_code=404, detail="Airport not found")
    for key, value in airport.model_dump().items():
        setattr(db_airport, key, value)
    db.commit()
    db.refresh(db_airport)
    return db_airport

@app.delete("/airports/{code}")
def delete_airport(
    code: str,
    db: db_dependency
):
    """Delete an airport by code"""
    db_airport = db.query(models.Airport).filter(models.Airport.code == code).first()
    if not db_airport:
        raise HTTPException(status_code=404, detail="Airport not found")
    db.delete(db_airport)
    db.commit()
    return {"detail": "Airport deleted"}

# ------------------- Airline Endpoints -------------------
@app.get("/airlines/", response_model=List[schemas.AirlinePublic])
def get_airlines(
    db: db_dependency,
    skip: int = 0,
    limit: int = 100
):
    airlines = db.query(models.Airline).offset(skip).limit(limit).all()
    return airlines

@app.post("/airlines/", response_model=schemas.AirlinePublic)
def create_airline(
    airline: schemas.AirlineBase,
    db: db_dependency
):
    db_airline = models.Airline(**airline.model_dump())
    db.add(db_airline)
    db.commit()
    db.refresh(db_airline)
    return db_airline

@app.put("/airlines/{id}", response_model=schemas.AirlinePublic)
def update_airline(
    id: int,
    airline: schemas.AirlineBase,
    db: db_dependency
):
    db_airline = db.query(models.Airline).filter(models.Airline.id == id).first()
    if not db_airline:
        raise HTTPException(status_code=404, detail="Airline not found")
    for key, value in airline.model_dump().items():
        setattr(db_airline, key, value)
    db.commit()
    db.refresh(db_airline)
    return db_airline

@app.delete("/airlines/{id}")
def delete_airline(
    id: int,
    db: db_dependency
):
    db_airline = db.query(models.Airline).filter(models.Airline.id == id).first()
    if not db_airline:
        raise HTTPException(status_code=404, detail="Airline not found")
    db.delete(db_airline)
    db.commit()
    return {"detail": "Airline deleted"}

# ------------------- Flight Endpoints (CRUD for Admin Panel) -------------------
@app.put("/flights/{id}", response_model=schemas.FlightPublic)
def update_flight(
    id: int,
    flight: schemas.FlightCreate,
    db: db_dependency
):
    db_flight = db.query(models.Flight).filter(models.Flight.id == id).first()
    if not db_flight:
        raise HTTPException(status_code=404, detail="Flight not found")
    for key, value in flight.model_dump().items():
        setattr(db_flight, key, value)
    db.commit()
    db.refresh(db_flight)
    return db_flight

@app.delete("/flights/{id}")
def delete_flight(
    id: int,
    db: db_dependency
):
    db_flight = db.query(models.Flight).filter(models.Flight.id == id).first()
    if not db_flight:
        raise HTTPException(status_code=404, detail="Flight not found")
    db.delete(db_flight)
    db.commit()
    return {"detail": "Flight deleted"}

# ------------------- Passenger Endpoints (CRUD for Admin Panel) -------------------
@app.put("/passengers/{id}", response_model=schemas.PassengerPublic)
def update_passenger(
    id: int,
    passenger: schemas.PassengerCreate,
    db: db_dependency
):
    db_passenger = db.query(models.Passenger).filter(models.Passenger.id == id).first()
    if not db_passenger:
        raise HTTPException(status_code=404, detail="Passenger not found")
    for key, value in passenger.model_dump().items():
        setattr(db_passenger, key, value)
    db.commit()
    db.refresh(db_passenger)
    return db_passenger

@app.delete("/passengers/{id}")
def delete_passenger(
    id: int,
    db: db_dependency
):
    db_passenger = db.query(models.Passenger).filter(models.Passenger.id == id).first()
    if not db_passenger:
        raise HTTPException(status_code=404, detail="Passenger not found")
    db.delete(db_passenger)
    db.commit()
    return {"detail": "Passenger deleted"}

# ------------------- Promotion Endpoints (CRUD for Admin Panel) -------------------
@app.get("/promotions/", response_model=List[schemas.PromotionPublic])
def get_promotions(
    db: db_dependency,
    skip: int = 0,
    limit: int = 100
):
    promotions = db.query(models.Promotion).offset(skip).limit(limit).all()
    return promotions

@app.post("/promotions/", response_model=schemas.PromotionPublic)
def create_promotion(
    promotion: schemas.PromotionBase,
    db: db_dependency
):
    db_promo = models.Promotion(**promotion.model_dump())
    db.add(db_promo)
    db.commit()
    db.refresh(db_promo)
    return db_promo

@app.put("/promotions/{promo_id}", response_model=schemas.PromotionPublic)
def update_promotion(
    promo_id: str,
    promotion: schemas.PromotionBase,
    db: db_dependency
):
    db_promo = db.query(models.Promotion).filter(models.Promotion.promo_id == promo_id).first()
    if not db_promo:
        raise HTTPException(status_code=404, detail="Promotion not found")
    for key, value in promotion.model_dump().items():
        setattr(db_promo, key, value)
    db.commit()
    db.refresh(db_promo)
    return db_promo

@app.delete("/promotions/{promo_id}")
def delete_promotion(
    promo_id: str,
    db: db_dependency
):
    db_promo = db.query(models.Promotion).filter(models.Promotion.promo_id == promo_id).first()
    if not db_promo:
        raise HTTPException(status_code=404, detail="Promotion not found")
    db.delete(db_promo)
    db.commit()
    return {"detail": "Promotion deleted"}
