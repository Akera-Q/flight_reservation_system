# import sys
# from sqlalchemy.exc import SQLAlchemyError
# from sqlalchemy import create_engine
# from sqlalchemy.orm import sessionmaker
# from models import Base, Country, Airport, Flight, Airline
# from datetime import datetime, timedelta

# # Database connection
# DATABASE_URL = "sqlite:///./flight_reservation.db"
# engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
# SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# def insert_test_data():
#     db = SessionLocal()
#     try:
#         # Insert Country
#         print("⏳ Inserting country...")
#         country = Country(
#             code="US",
#             name="United States",
#             continent="North America",
#             official_language="English",
#             is_schengen_zone_member=False
#         )
#         db.add(country)
#         db.commit()
#         print("✅ Country inserted successfully!")

#         # Insert Airport
#         print("\n⏳ Inserting airport...")
#         airport = Airport(
#             code="JFK",
#             name="John F. Kennedy International Airport",
#             location="New York",
#             country_code="US",
#             number_of_terminals=6
#         )
#         db.add(airport)
#         db.commit()
#         print("✅ Airport inserted successfully!")

#         # Insert Airline (needed for flight)
#         print("\n⏳ Inserting airline...")
#         airline = Airline(
#             name="Delta Airlines",
#             iata_code="DL",
#             icao_code="DAL",
#             headquarters="Atlanta, Georgia",
#             year_founded=1928,
#             base_airport_code="JFK"
#         )
#         db.add(airline)
#         db.commit()
#         print("✅ Airline inserted successfully!")

#         # Insert Flight
#         print("\n⏳ Inserting flight...")
#         flight = Flight(
#             flight_number="DL123",
#             departure_code="JFK",
#             destination_code="LAX",
#             departure_time=datetime.now() + timedelta(days=1),
#             arrival_time=datetime.now() + timedelta(days=1, hours=6),
#             total_seats=150,
#             available_seats=150,
#             airline_id=1,  # Assuming this is the ID of the airline we just inserted
#             gate="B12",
#             terminal="4",
#             days_of_operation=127  # Binary 1111111 (operates all days)
#         )
#         db.add(flight)
#         db.commit()
#         print("✅ Flight inserted successfully!")

#         print("\n🎉 All test data inserted successfully!")

#     except SQLAlchemyError as e:
#         db.rollback()
#         print(f"\n❌ Error occurred: {str(e)}", file=sys.stderr)
#         print("⚠️  No data was inserted due to the error", file=sys.stderr)
#     finally:
#         db.close()

# if __name__ == "__main__":
#     print("\n" + "="*50)
#     print("FLIGHT SYSTEM TEST DATA INSERTION")
#     print("="*50 + "\n")
    
#     insert_test_data()
    
#     print("\nOperation completed. Check your database.")
# insertion.py
## from sqlalchemy.orm import Session
## from database import engine
## from models import Country, Airport
## from datetime import datetime

# from sqlalchemy.orm import Session
# from database import SessionLocal, engine
# from models import Base, Country, Airport, Airline, User, Flight
# from datetime import datetime, timedelta

# # Make sure tables exist
# Base.metadata.create_all(bind=engine)

# # Start session
# db: Session = SessionLocal()

# try:
#     # 1. Country
#     country = Country(
#         code="US",
#         name="United States",
#         continent="North America",
#         official_language="English",
#         is_schengen_zone_member=False
#     )
#     db.add(country)

#     # 2. Airport
#     airport = Airport(
#         code="JFK",
#         name="John F. Kennedy International Airport",
#         country_code="US",
#         location="New York",
#         number_of_terminals=6
#     )
#     db.add(airport)

#     # 3. Airline
#     airline = Airline(
#         name="SampleAir",
#         iata_code="SA",
#         icao_code="SMP",
#         base_airport_code="JFK",
#         headquarters="New York",
#         year_founded=2000
#     )
#     db.add(airline)

#     # 4. User (admin or staff who owns the flight)
#     user = User(
#         username="admin",
#         email="admin@example.com",
#         password="Admin123"  # Assuming model handles hashing
#     )
#     db.add(user)

#     db.flush()  # Get generated IDs

#     # 5. Flight
#     flight = Flight(
#         flight_number="SA100",
#         departure_code="JFK",
#         destination_code="JFK",  # Roundtrip for simplicity
#         departure_time=datetime.utcnow() + timedelta(days=1),
#         arrival_time=datetime.utcnow() + timedelta(days=1, hours=5),
#         total_seats=180,
#         gate="A12",
#         terminal="4",
#         airline_id=airline.id,
#         days_of_operation=127,  # All week
#     )
#     db.add(flight)

#     db.commit()
#     print("✅ Sample flight and required entities inserted successfully.")

# except Exception as e:
#     db.rollback()
#     print("❌ Error inserting sample data:", str(e))

# finally:
#     db.close()

# insertion.py

from database import SessionLocal
from models import Administrator

def insert_admin():
    session = SessionLocal()

    try:
        admin = Administrator(
            adminID="admin001",
            name="admin",
            role="superadmin",
            password="admin",  # Ideally you'd hash this
            contactEmail="admin@gmail.com",
            hasManagementAccess=True
        )

        session.add(admin)
        session.commit()
        print("✅ Admin inserted successfully.")

    except Exception as e:
        session.rollback()
        print(f"❌ Failed to insert admin: {e}")
    finally:
        session.close()

if __name__ == "__main__":
    insert_admin()
