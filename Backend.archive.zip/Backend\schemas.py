from datetime import datetime, date
from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field, field_validator, ConfigDict
from pydantic.types import Decimal
import re

# Base Config
model_config = ConfigDict(from_attributes=True)

# ------------------- User Schemas -------------------
class UserBase(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    # Add this if you want to expose it everywhere
    # booked_flights: Optional[str] = ""

class UserCreate(UserBase):
    password: str = Field(..., min_length=8, max_length=100)

    @field_validator('password')
    @classmethod
    def validate_password(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        if not re.search(r'[A-Z]', v):
            raise ValueError("Password must contain at least one uppercase letter")
        if not re.search(r'[a-z]', v):
            raise ValueError("Password must contain at least one lowercase letter")
        if not re.search(r'\d', v):
            raise ValueError("Password must contain at least one digit")
        return v

class UserPublic(UserBase):
    id: int
    is_active: bool
    booked_flights: Optional[str] = "" 

# ------------------- Country Schemas -------------------
class CountryBase(BaseModel):
    code: str = Field(..., min_length=2, max_length=2, pattern=r'^[A-Z]{2}$')
    name: str = Field(..., min_length=2, max_length=100)
    continent: Optional[str] = None
    official_language: Optional[str] = None
    is_schengen_zone_member: bool = False

class CountryPublic(CountryBase):
    pass

# ------------------- Airport Schemas -------------------
class AirportBase(BaseModel):
    code: str = Field(..., min_length=3, max_length=3, pattern=r'^[A-Z]{3}$')
    name: str
    country_code: str = Field(..., min_length=2, max_length=2)
    number_of_terminals: int = Field(..., ge=1)
    location: Optional[str] = None

class AirportPublic(AirportBase):
    pass

class AirportWithCountry(AirportPublic):
    country: Optional[CountryPublic] = None

# ------------------- Airline Schemas -------------------
class AirlineBase(BaseModel):
    name: str
    iata_code: str = Field(..., min_length=2, max_length=2)
    icao_code: str = Field(..., min_length=3, max_length=3)
    base_airport_code: str = Field(..., min_length=3, max_length=3)
    headquarters: Optional[str] = None
    year_founded: Optional[int] = None

class AirlinePublic(AirlineBase):
    id: int
    base_airport: Optional[AirportWithCountry] = None

# ------------------- Flight Schemas -------------------
class FlightBase(BaseModel):
    flight_number: str = Field(..., min_length=2, max_length=10, pattern=r'^[A-Za-z0-9]+$')
    departure_code: str = Field(..., min_length=3, max_length=3, pattern=r'^[A-Z]{3}$')
    destination_code: str = Field(..., min_length=3, max_length=3, pattern=r'^[A-Z]{3}$')
    departure_time: datetime
    arrival_time: datetime
    total_seats: int = Field(..., gt=0)
    gate: Optional[str] = None
    terminal: Optional[str] = None
    airline_id: Optional[int] = None
    days_of_operation: Optional[str] = None

    @field_validator('departure_code', 'destination_code')
    @classmethod
    def validate_airport_codes(cls, v: str) -> str:
        return v.upper()

    @field_validator('arrival_time')
    @classmethod
    def validate_arrival_time(cls, v: datetime, values) -> datetime:
        if 'departure_time' in values.data and v <= values.data['departure_time']:
            raise ValueError("Arrival must be after departure")
        return v

class FlightCreate(FlightBase):
    pass

class FlightPublic(FlightBase):
    id: int

class FlightWithDetails(FlightPublic):
    airline: Optional[AirlinePublic] = None
    departure_airport: Optional[AirportWithCountry] = None
    destination_airport: Optional[AirportWithCountry] = None

# ------------------- Passenger Schemas -------------------
class PassengerBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    national_id: str = Field(..., min_length=5, max_length=20)
    email: EmailStr
    phone_number: str = Field(..., min_length=5, max_length=20)
    nationality: str = Field(..., min_length=2, max_length=50)

class PassengerCreate(PassengerBase):
    passport_number: str = Field(..., min_length=5, max_length=20)
    date_of_birth: datetime
    is_vip: bool = False
    address: Optional[str] = None
    gender: Optional[str] = None
    frequent_flyer_number: Optional[str] = None

class PassengerPublic(PassengerBase):
    id: int
    passport_number: str
    is_vip: bool
    address: Optional[str] = None
    date_of_birth: Optional[datetime] = None
    gender: Optional[str] = None
    frequent_flyer_number: Optional[str] = None

# ------------------- Promotion Schemas -------------------
class PromotionBase(BaseModel):
    promo_id: str
    description: str
    discount_percentage: Decimal = Field(..., ge=0, le=100)
    start_date: datetime
    end_date: datetime
    promo_code: str
    min_purchase: Decimal = Field(..., ge=0)
    max_discount: Optional[Decimal] = None
    usage_limit: Optional[int] = None

class PromotionCreate(PromotionBase):
    pass

class PromotionPublic(PromotionBase):
    id: str
    usage_count: Optional[int] = None
    is_active: Optional[bool] = None

# ------------------- Reservation Schemas -------------------
class ReservationBase(BaseModel):
    username: str
    flight_id: int
    seat_number: str = Field(..., pattern=r'^[0-9]+[A-Z]$')

class ReservationCreate(ReservationBase):
    status: str = "Pending"
    booking_agent_id: Optional[str] = None

class ReservationPublic(ReservationBase):
    id: int
    status: str
    created_at: datetime

# ------------------- Ticket Schemas -------------------
class TicketBase(BaseModel):
    passenger_id: int
    flight_id: int
    seat_number: str
    ticket_class: str = Field(..., pattern=r'^(economy|business|first)$')
    reservation_id: int

class TicketCreate(TicketBase):
    status: str = "active"
    is_changeable: Optional[bool] = None
    is_refundable: Optional[bool] = None
    promotion_id: Optional[str] = None

class TicketPublic(TicketBase):
    id: int
    status: str
    issue_date: datetime
    base_price: Decimal = Field(..., gt=0)
    final_price: Decimal = Field(..., gt=0)

# ------------------- Payment Schemas -------------------
class PaymentBase(BaseModel):
    amount: Decimal = Field(..., gt=0)
    method: str = Field(..., pattern=r'^(credit card|debit card|bank transfer|cash)$')
    reservation_id: int
    currency: str = Field(..., min_length=3, max_length=3)

class PaymentCreate(PaymentBase):
    status: str = "pending"
    transaction_id: Optional[str] = None

class PaymentPublic(PaymentBase):
    id: str
    status: str
    payment_date: datetime
    is_refundable: bool

# ------------------- Seat Schemas -------------------
class SeatBase(BaseModel):
    seat_number: str
    class_type: str
    is_available: bool
    flight_id: int

class SeatPublic(SeatBase):
    id: int
    seat_type: Optional[str] = None
    additional_features: Optional[List[str]] = None

# ------------------- Search-related Schemas -------------------
class FlightSearchRequest(BaseModel):
    departure_code: str = Field(..., min_length=3, max_length=3)
    destination_code: str = Field(..., min_length=3, max_length=3)
    departure_date: date
    class_type: str = Field("economy", pattern=r'^(economy|premium economy|business|first)$')
    travellers: int = Field(1, ge=1, le=10)

class FlightSearchResponse(BaseModel):
    flights: List[FlightWithDetails]
    total_results: int
    page: int
    page_size: int