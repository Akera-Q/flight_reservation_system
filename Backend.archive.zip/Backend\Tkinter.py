import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from PIL import Image, ImageTk  # If you use images in your GUI
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
import os
# Import your models and database session
from models import User, Administrator, Reservation, Flight, Seat, Payment, Promotion, Luggage, Loyalty_program, Airport, Country, Airline, Ticket, Passenger, init_db, get_session


# Initialize the database session
init_db()
session = get_session()

# Create the main application window
class FlightReservationApp(tk.Tk):

    def __init__(self):
        super().__init__()
        
        self.title("Flight Reservation System")
        self.geometry("800x600")    
            # Bind the "X" button to the on_close method
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self.style = ttk.Style()
        self.style.theme_use("clam")  # Use a modern theme like 'clam', 'alt', or 'default'
        self.style.configure("TButton", font=("Helvetica", 12), padding=5)
        self.style.configure("TLabel", font=("Helvetica", 12))
        self.style.configure("TFrame", padding=10)
        self.style.configure("TNotebook.Tab", font=("Helvetica", 12, "bold"), padding=[10, 5])
        self.style.map("TNotebook.Tab", background=[("selected", "#007acc")], foreground=[("selected", "white")])

        # Create a tabbed interface
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill="both")
            # Add a navigation bar
        nav_bar = tk.Frame(self, bg="#007acc")
        nav_bar.pack(side="top", fill="x")

    # Add a termination button to the navigation bar
        terminate_button = tk.Button(
            nav_bar,
            text="Terminate Program",
            command=self.on_close,
            bg="#ff4d4d",
            fg="white",
            font=("Helvetica", 12, "bold"),
            relief="flat",
            padx=10,
            pady=5
        )
        terminate_button.pack(side="right", padx=10, pady=5)



        self.add_sign_in_tab()
        

        # Add all other tabs (but disable them initially)
        self.tabs = [
            self.add_country_tab,
            self.add_airport_tab,
            self.add_airline_tab,
            self.add_administrator_tab,
            self.add_flight_tab,
            self.add_passenger_tab,
            self.add_seat_tab,
            self.add_reservation_tab,
            self.add_ticket_tab,
            self.add_payment_tab,
            self.add_promotion_tab,
            self.add_luggage_tab,
            self.add_loyalty_program_tab,
            self.add_airport_image_tab,
            self.add_user_tab,
            self.tab
        ]
        self.add_all_tabs()
        #self.disable_all_tabs()

    def on_close(self):
        """Handle the termination of the program."""
        if messagebox.askokcancel("Quit", "Do you really want to quit?"):
            self.destroy()          
    def tab(self):
        pass
    def add_all_tabs(self):
        """Add all tabs to the notebook."""
        self.tab_objects = []  # Store references to the tab objects
        for tab_method in self.tabs:
            tab = tab_method()  # Call the method to create the tab
            self.tab_objects.append(tab)  # Store the tab object for future reference

    def disable_all_tabs(self):
        """Disable all tabs except the Sign In / Sign Up tab."""
        for index, tab in enumerate(self.tab_objects):
            if index > 0:  # Skip the first tab (Sign In / Sign Up)
                self.notebook.tab(index, state="hidden")
                print(f"Tab {index} hidden.") 
    def enable_all_tabs(self):
        """Enable all tabs after successful sign-in."""
        for index, tab in enumerate(self.tab_objects):
            if index > 0:  # Skip the first tab (Sign In / Sign Up)
                self.notebook.tab(index, state="normal")

                print(f"Tab {index} enabled.") 
    def enable_reservations_tab_only(self):
        """Enable only the Reservations tab for users."""
        for index, tab in enumerate(self.tab_objects):
            if self.tabs[index] == self.add_ticket_tab:
                self.notebook.tab(index, state="normal")  # Enable the Reservations tab
                print(f"Tab {index} (Reservations) enabled.")


    def create_scrollable_frame(self, parent):
        """Create a scrollable frame inside the given parent widget."""
        # Create a canvas and a vertical scrollbar
        canvas = tk.Canvas(parent)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        # Configure the canvas to use the scrollbar
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Pack the canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        return scrollable_frame


    def add_sign_in_tab(self):
        """Add the Sign In / Sign Up tab."""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Sign In / Sign Up")
        # Create a scrollable frame inside the tab
        scrollable_frame = self.create_scrollable_frame(tab)

        # Sign-In Section
        tk.Label(scrollable_frame, text="Sign In", font=("Helvetica", 16)).grid(row=0, column=0, columnspan=2, pady=10)

        tk.Label(scrollable_frame, text="Username:").grid(row=1, column=0, padx=10, pady=5)
        username_entry = tk.Entry(scrollable_frame)
        username_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Email:").grid(row=2, column=0, padx=10, pady=5)
        email_entry = tk.Entry(scrollable_frame)
        email_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Password:").grid(row=3, column=0, padx=10, pady=5)
        password_entry = tk.Entry(scrollable_frame, show="*")
        password_entry.grid(row=3, column=1, padx=10, pady=5)
        
        def sign_in():
            try:
                # Check if the credentials belong to an admin
                is_admin = Administrator.authenticate_admin(
                    session,
                    adminID=username_entry.get(),
                    email=email_entry.get(),
                    password=password_entry.get()
                )
                if is_admin:
                    messagebox.showinfo("Success", "Admin sign-in successful!")
                    # Enable all tabs and remove the Sign In / Sign Up tab
                    self.enable_all_tabs()
                    self.notebook.forget(tab)  # Remove the parent tab
                    return

                # If not an admin, check if the credentials belong to a user
                is_user = User.authenticate_user(
                    session,
                    username=username_entry.get(),
                    email=email_entry.get(),
                    password=password_entry.get()
                )
                if is_user:
                    messagebox.showinfo("Success", "User sign-in successful!")
                    # Enable all tabs and remove the Sign In / Sign Up tab
                    self.enable_reservations_tab_only()
                    self.notebook.forget(tab)  # Remove the parent tab
                else:
                    messagebox.showerror("Error", "Sign-in failed: Invalid credentials.")
            except Exception as e:
                messagebox.showerror("Error", f"Sign-in failed: {e}")

        tk.Button(scrollable_frame, text="Sign In", command=sign_in).grid(row=4, column=0, columnspan=2, pady=10)

        # Sign-Up Section
        tk.Label(scrollable_frame, text="Sign Up", font=("Helvetica", 16)).grid(row=5, column=0, columnspan=2, pady=10)

        tk.Label(scrollable_frame, text="Username:").grid(row=6, column=0, padx=10, pady=5)
        signup_username_entry = tk.Entry(scrollable_frame)
        signup_username_entry.grid(row=6, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Email:").grid(row=7, column=0, padx=10, pady=5)
        signup_email_entry = tk.Entry(scrollable_frame)
        signup_email_entry.grid(row=7, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Password:").grid(row=8, column=0, padx=10, pady=5)
        signup_password_entry = tk.Entry(scrollable_frame, show="*")
        signup_password_entry.grid(row=8, column=1, padx=10, pady=5)

        def sign_up():
            try:
                # Create a new user
                User.create_user(
                    session,
                    username=signup_username_entry.get(),
                    email=signup_email_entry.get(),
                    password=signup_password_entry.get()
                )
                messagebox.showinfo("Success", "Sign-up successful! You can now sign in.")
            except Exception as e:
                messagebox.showerror("Error", f"Sign-up failed: {e}")

        tk.Button(scrollable_frame, text="Sign Up", command=sign_up).grid(row=9, column=0, columnspan=2, pady=10)


    def add_country_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Country")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Country
        tk.Label(scrollable_frame, text="Name:").grid(row=0, column=0, padx=10, pady=5)
        name_entry = tk.Entry(scrollable_frame)
        name_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Code:").grid(row=1, column=0, padx=10, pady=5)
        code_entry = tk.Entry(scrollable_frame)
        code_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Continent:").grid(row=2, column=0, padx=10, pady=5)
        continent_entry = tk.Entry(scrollable_frame)
        continent_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Official Language:").grid(row=3, column=0, padx=10, pady=5)
        language_entry = tk.Entry(scrollable_frame)
        language_entry.grid(row=3, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Schengen Zone Member:").grid(row=4, column=0, padx=10, pady=5)
        schengen_var = tk.BooleanVar()
        schengen_checkbox = tk.Checkbutton(scrollable_frame, variable=schengen_var)
        schengen_checkbox.grid(row=4, column=1, padx=10, pady=5)

        # Add Country Button
        def add_country():
            try:
                country = Country(
                    name=name_entry.get(),
                    code=code_entry.get(),
                    continent=continent_entry.get(),
                    official_language=language_entry.get(),
                    is_schengen_zone_member=schengen_var.get()
                )
                session.add(country)
                session.commit()
                messagebox.showinfo("Success", "Country added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add country: {e}")

        tk.Button(scrollable_frame, text="Add Country", command=add_country).grid(row=5, column=0, columnspan=2, pady=10)

    def add_airport_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Airport")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Airport Attributes
        tk.Label(scrollable_frame, text="Name:").grid(row=0, column=0, padx=10, pady=5)
        name_entry = tk.Entry(scrollable_frame)
        name_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Code:").grid(row=1, column=0, padx=10, pady=5)
        code_entry = tk.Entry(scrollable_frame)
        code_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Location:").grid(row=2, column=0, padx=10, pady=5)
        location_entry = tk.Entry(scrollable_frame)
        location_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Country Code:").grid(row=3, column=0, padx=10, pady=5)
        country_code_entry = tk.Entry(scrollable_frame)
        country_code_entry.grid(row=3, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Number of Terminals:").grid(row=4, column=0, padx=10, pady=5)
        terminals_entry = tk.Entry(scrollable_frame)
        terminals_entry.grid(row=4, column=1, padx=10, pady=5)

        # Add Airport Button
        def add_airport():
            try:
                airport = Airport(
                    name=name_entry.get(),
                    code=code_entry.get(),
                    location=location_entry.get(),
                    country_code=country_code_entry.get(),
                    number_of_terminals=int(terminals_entry.get())
                )
                session.add(airport)
                session.commit()
                messagebox.showinfo("Success", "Airport added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add airport: {e}")

        tk.Button(scrollable_frame, text="Add Airport", command=add_airport).grid(row=5, column=0, columnspan=2, pady=10)

        # Horizontal Line
        ttk.Separator(scrollable_frame, orient="horizontal").grid(row=6, column=0, columnspan=2, sticky="ew", pady=10)

        # Fields for Flight Attributes
        tk.Label(scrollable_frame, text="Flight Number:").grid(row=7, column=0, padx=10, pady=5)
        flight_number_entry = tk.Entry(scrollable_frame)
        flight_number_entry.grid(row=7, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Departure Code:").grid(row=8, column=0, padx=10, pady=5)
        departure_code_entry = tk.Entry(scrollable_frame)
        departure_code_entry.grid(row=8, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Destination Code:").grid(row=9, column=0, padx=10, pady=5)
        destination_code_entry = tk.Entry(scrollable_frame)
        destination_code_entry.grid(row=9, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Departure Time (YYYY-MM-DD HH:MM):").grid(row=10, column=0, padx=10, pady=5)
        departure_time_entry = tk.Entry(scrollable_frame)
        departure_time_entry.grid(row=10, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Arrival Time (YYYY-MM-DD HH:MM):").grid(row=11, column=0, padx=10, pady=5)
        arrival_time_entry = tk.Entry(scrollable_frame)
        arrival_time_entry.grid(row=11, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Total Seats:").grid(row=12, column=0, padx=10, pady=5)
        total_seats_entry = tk.Entry(scrollable_frame)
        total_seats_entry.grid(row=12, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Gate:").grid(row=13, column=0, padx=10, pady=5)
        gate_entry = tk.Entry(scrollable_frame)
        gate_entry.grid(row=13, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Terminal:").grid(row=14, column=0, padx=10, pady=5)
        terminal_entry = tk.Entry(scrollable_frame)
        terminal_entry.grid(row=14, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Airline ID:").grid(row=15, column=0, padx=10, pady=5)
        airline_id_entry = tk.Entry(scrollable_frame)
        airline_id_entry.grid(row=15, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Days of Operation:").grid(row=16, column=0, padx=10, pady=5)
        days_of_operation_entry = tk.Entry(scrollable_frame)
        days_of_operation_entry.grid(row=16, column=1, padx=10, pady=5)

        # Display Area
        display_area = tk.Text(scrollable_frame, height=10, width=60)
        display_area.grid(row=17, column=0, columnspan=2, padx=10, pady=10)

        # Add Flight Button
        def create_flight():
            try:
                Airport.create_flight(
                    session,
                    departure_code=departure_code_entry.get(),
                    flight_number=flight_number_entry.get(),
                    destination_code=destination_code_entry.get(),
                    departure_time=datetime.strptime(departure_time_entry.get(), "%Y-%m-%d %H:%M"),
                    arrival_time=datetime.strptime(arrival_time_entry.get(), "%Y-%m-%d %H:%M"),
                    total_seats=int(total_seats_entry.get()),
                    gate=gate_entry.get(),
                    terminal=terminal_entry.get(),
                    airline_id=int(airline_id_entry.get()),
                    days_of_operation=int(days_of_operation_entry.get())
                )
                display_area.insert(tk.END, f"Flight {flight_number_entry.get()} created successfully.\n")
            except Exception as e:
                session.rollback()
                display_area.insert(tk.END, f"Error creating flight: {e}\n")

        def delete_flight():
            try:
                Airline.delete_flight(session, flight_number=flight_number_entry) 
                display_area.insert(tk.END, f"Flight deleted successfully for Airline {name_entry.get()}.\n")
            except Exception as e:
                session.rollback()
                display_area.insert(tk.END, f"Error deleting flight: {e}\n")

        def manage_seats():
            try:
                # Query the flight by flight number
                flight = session.query(Flight).filter_by(flight_number=flight_number_entry.get()).first()
                if not flight:
                    display_area.insert(tk.END, f"No flight found with Flight Number {flight_number_entry.get()}.\n")
                    return

                # Display flight details
                display_area.insert(tk.END, f"Managing seats for Flight {flight.flight_number}:\n")

                # Query and display all seats for the flight
                seats = session.query(Seat).filter_by(flight_id=flight.id).all()
                if not seats:
                    display_area.insert(tk.END, "No seats found for this flight.\n")
                    return

                for seat in seats:
                    display_area.insert(
                        tk.END,
                        f"Seat ID: {seat.seat_id}, Seat Number: {seat.seat_number}, "
                        f"Class Type: {seat.class_type}, Availability: {'Available' if seat.is_available else 'Reserved'}, "
                        f"Seat Type: {seat.seat_type}\n"
                    )
            except Exception as e:
                display_area.insert(tk.END, f"Error managing seats: {e}\n")

        tk.Button(scrollable_frame, text="Create Flight", command=create_flight).grid(row=18, column=0, columnspan=2, pady=10)
        tk.Button(scrollable_frame, text="Delete Flight", command=delete_flight).grid(row=19, column=0, columnspan=2, pady=10)
        tk.Button(scrollable_frame, text="Manage Seats", command=manage_seats).grid(row=20, column=0, columnspan=2, pady=10)
        return tab

    def add_airline_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Airline")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Airline
        tk.Label(scrollable_frame, text="Name:").grid(row=0, column=0, padx=10, pady=5)
        name_entry = tk.Entry(scrollable_frame)
        name_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="IATA Code:").grid(row=1, column=0, padx=10, pady=5)
        iata_entry = tk.Entry(scrollable_frame)
        iata_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="ICAO Code:").grid(row=2, column=0, padx=10, pady=5)
        icao_entry = tk.Entry(scrollable_frame)
        icao_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Headquarters:").grid(row=3, column=0, padx=10, pady=5)
        hq_entry = tk.Entry(scrollable_frame)
        hq_entry.grid(row=3, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Year Founded:").grid(row=4, column=0, padx=10, pady=5)
        year_entry = tk.Entry(scrollable_frame)
        year_entry.grid(row=4, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Base Airport Code:").grid(row=5, column=0, padx=10, pady=5)
        base_airport_entry = tk.Entry(scrollable_frame)
        base_airport_entry.grid(row=5, column=1, padx=10, pady=5)

        # Add Airline Button
        def add_airline():
            try:
                airline = Airline(
                    name=name_entry.get(),
                    iata_code=iata_entry.get(),
                    icao_code=icao_entry.get(),
                    headquarters=hq_entry.get(),
                    year_founded=int(year_entry.get()),
                    base_airport_code=base_airport_entry.get()
                )
                session.add(airline)
                session.commit()
                messagebox.showinfo("Success", "Airline added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add airline: {e}")

        tk.Button(scrollable_frame, text="Add Airline", command=add_airline).grid(row=6, column=0, columnspan=2, pady=10)


    def add_administrator_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Administrator")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Administrator
        tk.Label(scrollable_frame, text="Admin ID:").grid(row=0, column=0, padx=10, pady=5)
        admin_id_entry = tk.Entry(scrollable_frame)
        admin_id_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Name:").grid(row=1, column=0, padx=10, pady=5)
        name_entry = tk.Entry(scrollable_frame)
        name_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Role:").grid(row=2, column=0, padx=10, pady=5)
        role_entry = tk.Entry(scrollable_frame)
        role_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Contact Email:").grid(row=3, column=0, padx=10, pady=5)
        email_entry = tk.Entry(scrollable_frame)
        email_entry.grid(row=3, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Management Access:").grid(row=4, column=0, padx=10, pady=5)
        has_access_var = tk.BooleanVar()
        has_access_checkbox = tk.Checkbutton(scrollable_frame, variable=has_access_var)
        has_access_checkbox.grid(row=4, column=1, padx=10, pady=5)

        # Add Administrator Button
        def add_administrator():
            try:
                admin = Administrator(
                    adminID=admin_id_entry.get(),
                    name=name_entry.get(),
                    role=role_entry.get(),
                    contactEmail=email_entry.get(),
                    hasManagementAccess=has_access_var.get()
                )
                session.add(admin)
                session.commit()
                messagebox.showinfo("Success", "Administrator added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add administrator: {e}")

        tk.Button(scrollable_frame, text="Add Administrator", command=add_administrator).grid(row=5, column=0, columnspan=2, pady=10)

        # Separator
        ttk.Separator(scrollable_frame, orient="horizontal").grid(row=6, column=0, columnspan=2, sticky="ew", pady=10)

        # Fields for Full Flight Details
        tk.Label(scrollable_frame, text="Flight Number:").grid(row=7, column=0, padx=10, pady=5)
        flight_number_entry = tk.Entry(scrollable_frame)
        flight_number_entry.grid(row=7, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Departure Code:").grid(row=8, column=0, padx=10, pady=5)
        departure_code_entry = tk.Entry(scrollable_frame)
        departure_code_entry.grid(row=8, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Destination Code:").grid(row=9, column=0, padx=10, pady=5)
        destination_code_entry = tk.Entry(scrollable_frame)
        destination_code_entry.grid(row=9, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Departure Time (YYYY-MM-DD HH:MM):").grid(row=10, column=0, padx=10, pady=5)
        departure_time_entry = tk.Entry(scrollable_frame)
        departure_time_entry.grid(row=10, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Arrival Time (YYYY-MM-DD HH:MM):").grid(row=11, column=0, padx=10, pady=5)
        arrival_time_entry = tk.Entry(scrollable_frame)
        arrival_time_entry.grid(row=11, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Total Seats:").grid(row=12, column=0, padx=10, pady=5)
        total_seats_entry = tk.Entry(scrollable_frame)
        total_seats_entry.grid(row=12, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Gate:").grid(row=13, column=0, padx=10, pady=5)
        gate_entry = tk.Entry(scrollable_frame)
        gate_entry.grid(row=13, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Terminal:").grid(row=14, column=0, padx=10, pady=5)
        terminal_entry = tk.Entry(scrollable_frame)
        terminal_entry.grid(row=14, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Airline ID:").grid(row=15, column=0, padx=10, pady=5)
        airline_id_entry = tk.Entry(scrollable_frame)
        airline_id_entry.grid(row=15, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Days of Operation:").grid(row=16, column=0, padx=10, pady=5)
        days_of_operation_entry = tk.Entry(scrollable_frame)
        days_of_operation_entry.grid(row=16, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Reservation to be managed (ID):").grid(row=17, column=0, padx=10, pady=5)
        reservation_id_entry = tk.Entry(scrollable_frame)
        reservation_id_entry.grid(row=17, column=1, padx=10, pady=5)

        # Display Area
        display_area = tk.Text(scrollable_frame, height=10, width=60)
        display_area.grid(row=18, column=0, columnspan=2, padx=10, pady=10)

        # Methods for Administrator
        def create_flight():
            try:
                Administrator.create_flight(
                    session,
                    airline_id=int(airline_id_entry.get()),
                    flight_number=flight_number_entry.get(),
                    departure_code=departure_code_entry.get(),
                    destination_code=destination_code_entry.get(),
                    departure_time=datetime.strptime(departure_time_entry.get(), "%Y-%m-%d %H:%M"),
                    arrival_time=datetime.strptime(arrival_time_entry.get(), "%Y-%m-%d %H:%M"),
                    total_seats=int(total_seats_entry.get()),
                    gate=gate_entry.get(),
                    terminal=terminal_entry.get(),
                    days_of_operation=int(days_of_operation_entry.get())
                )
                display_area.insert(tk.END, f"Flight {flight_number_entry.get()} created successfully.\n")
            except Exception as e:
                session.rollback()
                display_area.insert(tk.END, f"Error creating flight: {e}\n")

        def remove_flight():
            try:
                Administrator.remove_flight(session, flight_number_entry.get())
                display_area.insert(tk.END, f"Flight {flight_number_entry.get()} removed successfully.\n")
            except Exception as e:
                session.rollback()
                display_area.insert(tk.END, f"Error removing flight: {e}\n")

        def approve_reservation():
            try:
                reservation_id = int(reservation_id_entry.get())  # Assuming reservation ID is entered in the flight number field
                Administrator.approve_reservation(session, reservation_id)
                display_area.insert(tk.END, f"Reservation {reservation_id} approved successfully.\n")
            except Exception as e:
                session.rollback()
                display_area.insert(tk.END, f"Error approving reservation: {e}\n")

        def view_all_flights():
            try:
                flights = session.query(Flight).all()
                display_area.insert(tk.END, "Flights:\n")
                for flight in flights:
                    display_area.insert(tk.END, f"{flight}\n")
            except Exception as e:
                display_area.insert(tk.END, f"Error viewing flights: {e}\n")

        def view_all_reservations():
            try:
                reservations = session.query(Reservation).all()
                display_area.insert(tk.END, "Reservations:\n")
                for reservation in reservations:
                    display_area.insert(tk.END, f"ID: {reservation.id} Passenger ID {reservation.passenger_id} Seat Number {reservation.seat_number} Status {reservation.status}\n")
            except Exception as e:
                display_area.insert(tk.END, f"Error viewing reservations: {e}\n")

        # Buttons for Administrator Methods
        tk.Button(scrollable_frame, text="Create Flight", command=create_flight).grid(row=19, column=0, padx=10, pady=5)
        tk.Button(scrollable_frame, text="Remove Flight", command=remove_flight).grid(row=19, column=1, padx=10, pady=5)
        tk.Button(scrollable_frame, text="Approve Reservation", command=approve_reservation).grid(row=20, column=0, padx=10, pady=5)
        tk.Button(scrollable_frame, text="View All Flights", command=view_all_flights).grid(row=20, column=1, padx=10, pady=5)
        tk.Button(scrollable_frame, text="View All Reservations", command=view_all_reservations).grid(row=21, column=0, columnspan=2, pady=5)
        return tab

    def add_flight_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Flight")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Flight
        tk.Label(scrollable_frame, text="Flight Number:").grid(row=0, column=0, padx=10, pady=5)
        flight_number_entry = tk.Entry(scrollable_frame)
        flight_number_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Departure Code:").grid(row=1, column=0, padx=10, pady=5)
        departure_code_entry = tk.Entry(scrollable_frame)
        departure_code_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Destination Code:").grid(row=2, column=0, padx=10, pady=5)
        destination_code_entry = tk.Entry(scrollable_frame)
        destination_code_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Departure Time (YYYY-MM-DD HH:MM):").grid(row=3, column=0, padx=10, pady=5)
        departure_time_entry = tk.Entry(scrollable_frame)
        departure_time_entry.grid(row=3, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Arrival Time (YYYY-MM-DD HH:MM):").grid(row=4, column=0, padx=10, pady=5)
        arrival_time_entry = tk.Entry(scrollable_frame)
        arrival_time_entry.grid(row=4, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Total Seats:").grid(row=5, column=0, padx=10, pady=5)
        total_seats_entry = tk.Entry(scrollable_frame)
        total_seats_entry.grid(row=5, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Gate:").grid(row=6, column=0, padx=10, pady=5)
        gate_entry = tk.Entry(scrollable_frame)
        gate_entry.grid(row=6, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Terminal:").grid(row=7, column=0, padx=10, pady=5)
        terminal_entry = tk.Entry(scrollable_frame)
        terminal_entry.grid(row=7, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Airline ID:").grid(row=8, column=0, padx=10, pady=5)
        airline_id_entry = tk.Entry(scrollable_frame)
        airline_id_entry.grid(row=8, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Days of Operation:").grid(row=9, column=0, padx=10, pady=5)
        days_of_operation_entry = tk.Entry(scrollable_frame)
        days_of_operation_entry.grid(row=9, column=1, padx=10, pady=5)

        # Add Flight Button
        def add_flight():
            try:
                flight = Flight(
                    flight_number=flight_number_entry.get(),
                    departure_code=departure_code_entry.get(),
                    destination_code=destination_code_entry.get(),
                    departure_time=datetime.strptime(departure_time_entry.get(), "%Y-%m-%d %H:%M"),
                    arrival_time=datetime.strptime(arrival_time_entry.get(), "%Y-%m-%d %H:%M"),
                    total_seats=int(total_seats_entry.get()),
                    gate=gate_entry.get(),
                    terminal=terminal_entry.get(),
                    airline_id=int(airline_id_entry.get()),
                    days_of_operation=int(days_of_operation_entry.get())
                )
                session.add(flight)
                session.commit()
                messagebox.showinfo("Success", "Flight added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add flight: {e}")

        tk.Button(scrollable_frame, text="Add Flight", command=add_flight).grid(row=10, column=0, columnspan=2, pady=10)
        return tab
    def add_passenger_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Passenger")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Passenger
        tk.Label(scrollable_frame, text="Name:").grid(row=0, column=0, padx=10, pady=5)
        name_entry = tk.Entry(scrollable_frame)
        name_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="National ID:").grid(row=1, column=0, padx=10, pady=5)
        national_id_entry = tk.Entry(scrollable_frame)
        national_id_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Email:").grid(row=2, column=0, padx=10, pady=5)
        email_entry = tk.Entry(scrollable_frame)
        email_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Phone Number:").grid(row=3, column=0, padx=10, pady=5)
        phone_number_entry = tk.Entry(scrollable_frame)
        phone_number_entry.grid(row=3, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Nationality:").grid(row=4, column=0, padx=10, pady=5)
        nationality_entry = tk.Entry(scrollable_frame)
        nationality_entry.grid(row=4, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="VIP Status:").grid(row=5, column=0, padx=10, pady=5)
        is_vip_var = tk.BooleanVar()
        is_vip_checkbox = tk.Checkbutton(scrollable_frame, variable=is_vip_var)
        is_vip_checkbox.grid(row=5, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Address:").grid(row=6, column=0, padx=10, pady=5)
        address_entry = tk.Entry(scrollable_frame)
        address_entry.grid(row=6, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Date of Birth (YYYY-MM-DD):").grid(row=7, column=0, padx=10, pady=5)
        dob_entry = tk.Entry(scrollable_frame)
        dob_entry.grid(row=7, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Passport Number:").grid(row=8, column=0, padx=10, pady=5)
        passport_number_entry = tk.Entry(scrollable_frame)
        passport_number_entry.grid(row=8, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Gender:").grid(row=9, column=0, padx=10, pady=5)
        gender_entry = tk.Entry(scrollable_frame)
        gender_entry.grid(row=9, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Frequent Flyer Number:").grid(row=10, column=0, padx=10, pady=5)
        frequent_flyer_entry = tk.Entry(scrollable_frame)
        frequent_flyer_entry.grid(row=10, column=1, padx=10, pady=5)

        # Add Passenger Button
        def add_passenger():
            try:
                passenger = Passenger(
                    name=name_entry.get(),
                    national_id=national_id_entry.get(),
                    email=email_entry.get(),
                    phone_number=phone_number_entry.get(),
                    nationality=nationality_entry.get(),
                    is_vip=is_vip_var.get(),
                    address=address_entry.get(),
                    date_of_birth=dob_entry.get(),
                    passport_number=passport_number_entry.get(),
                    gender=gender_entry.get(),
                    frequent_flyer_number=frequent_flyer_entry.get()
                )
                session.add(passenger)
                session.commit()
                messagebox.showinfo("Success", "Passenger added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add passenger: {e}")

        tk.Button(scrollable_frame, text="Add Passenger", command=add_passenger).grid(row=11, column=0, columnspan=2, pady=10)
        return tab
    def add_seat_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Seat")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Seat
        tk.Label(scrollable_frame, text="Seat Number:").grid(row=0, column=0, padx=10, pady=5)
        seat_number_entry = tk.Entry(scrollable_frame)
        seat_number_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Class Type:").grid(row=1, column=0, padx=10, pady=5)
        class_type_entry = tk.Entry(scrollable_frame)
        class_type_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Seat Type:").grid(row=2, column=0, padx=10, pady=5)
        seat_type_entry = tk.Entry(scrollable_frame)
        seat_type_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Flight ID:").grid(row=3, column=0, padx=10, pady=5)
        flight_id_entry = tk.Entry(scrollable_frame)
        flight_id_entry.grid(row=3, column=1, padx=10, pady=5)

        # Add Seat Button
        def add_seat():
            try:
                seat = Seat(
                    seat_number=seat_number_entry.get(),
                    class_type=class_type_entry.get(),
                    is_available=True,
                    seat_type=seat_type_entry.get(),
                    flight_id=int(flight_id_entry.get())
                )
                session.add(seat)
                session.commit()
                messagebox.showinfo("Success", "Seat added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add seat: {e}")

        tk.Button(scrollable_frame, text="Add Seat", command=add_seat).grid(row=4, column=0, columnspan=2, pady=10)


    def add_reservation_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Reservation")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Searching Flights
        tk.Label(scrollable_frame, text="Departure Code:").grid(row=0, column=0, padx=10, pady=5)
        departure_code_entry = tk.Entry(scrollable_frame)
        departure_code_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Destination Code:").grid(row=1, column=0, padx=10, pady=5)
        destination_code_entry = tk.Entry(scrollable_frame)
        destination_code_entry.grid(row=1, column=1, padx=10, pady=5)

        # Display Area for Available Flights
        flights_display_area = tk.Text(scrollable_frame, height=10, width=60)
        flights_display_area.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

        # Button to Search Flights
        def search_flights():
            try:
                # Query flights based on departure and destination codes
                flights = session.query(Flight).filter_by(
                    departure_code=departure_code_entry.get(),
                    destination_code=destination_code_entry.get()
                ).all()

                # Clear the display area
                flights_display_area.delete("1.0", tk.END)

                if not flights:
                    flights_display_area.insert(tk.END, "No flights found for the given codes.\n")
                    return

                # Display available flights
                flights_display_area.insert(tk.END, "Available Flights:\n")
                for flight in flights:
                    flights_display_area.insert(
                        tk.END,
                        f"Flight ID: {flight.id}, Flight Number: {flight.flight_number}, "
                        f"Departure: {flight.departure_code}, Destination: {flight.destination_code}, "
                        f"Departure Time: {flight.departure_time}, Arrival Time: {flight.arrival_time}\n"
                    )
            except Exception as e:
                flights_display_area.insert(tk.END, f"Error searching flights: {e}\n")

        tk.Button(scrollable_frame, text="Search Flights", command=search_flights).grid(row=3, column=0, columnspan=2, pady=10)

        # Fields for Reserving a Seat
        tk.Label(scrollable_frame, text="Flight ID:").grid(row=4, column=0, padx=10, pady=5)
        flight_id_entry = tk.Entry(scrollable_frame)
        flight_id_entry.grid(row=4, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Passenger ID:").grid(row=5, column=0, padx=10, pady=5)
        passenger_id_entry = tk.Entry(scrollable_frame)
        passenger_id_entry.grid(row=5, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Seat Number:").grid(row=6, column=0, padx=10, pady=5)
        seat_number_entry = tk.Entry(scrollable_frame)
        seat_number_entry.grid(row=6, column=1, padx=10, pady=5)

        # Button to Reserve a Seat
        def reserve_seat():
            try:
                # Create a reservation
                reservation = Reservation(
                    session=session,
                    passenger_national_id=passenger_id_entry.get(),
                    departure_country_code=departure_code_entry.get(),
                    destination_country_code=destination_code_entry.get(),
                    seat_number=seat_number_entry.get()
                )
                session.add(reservation)
                session.commit()
                messagebox.showinfo("Success", f"Reservation created successfully! Reservation ID: {reservation.id}")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to create reservation: {e}")

        tk.Button(scrollable_frame, text="Reserve Seat", command=reserve_seat).grid(row=7, column=0, columnspan=2, pady=10)

        return tab

    def add_ticket_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Ticket")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Ticket
        tk.Label(scrollable_frame, text="Passenger ID:").grid(row=0, column=0, padx=10, pady=5)
        passenger_id_entry = tk.Entry(scrollable_frame)
        passenger_id_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Flight ID:").grid(row=1, column=0, padx=10, pady=5)
        flight_id_entry = tk.Entry(scrollable_frame)
        flight_id_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Seat Number:").grid(row=2, column=0, padx=10, pady=5)
        seat_number_entry = tk.Entry(scrollable_frame)
        seat_number_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Ticket Class:").grid(row=3, column=0, padx=10, pady=5)
        ticket_class_entry = tk.Entry(scrollable_frame)
        ticket_class_entry.grid(row=3, column=1, padx=10, pady=5)

        # Add Ticket Button
        def add_ticket():
            try:
                ticket = Ticket(
                    passenger_id=int(passenger_id_entry.get()),
                    flight_id=int(flight_id_entry.get()),
                    seat_number=seat_number_entry.get(),
                    ticket_class=ticket_class_entry.get()
                )
                session.add(ticket)
                session.commit()
                messagebox.showinfo("Success", "Ticket added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add ticket: {e}")

        tk.Button(scrollable_frame, text="Add Ticket", command=add_ticket).grid(row=4, column=0, columnspan=2, pady=10)
        return tab
    def add_payment_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Payment")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Payment
        tk.Label(scrollable_frame, text="Payment ID:").grid(row=0, column=0, padx=10, pady=5)
        payment_id_entry = tk.Entry(scrollable_frame)
        payment_id_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Amount:").grid(row=1, column=0, padx=10, pady=5)
        amount_entry = tk.Entry(scrollable_frame)
        amount_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Method:").grid(row=2, column=0, padx=10, pady=5)
        method_entry = tk.Entry(scrollable_frame)
        method_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Reservation ID:").grid(row=3, column=0, padx=10, pady=5)
        reservation_id_entry = tk.Entry(scrollable_frame)
        reservation_id_entry.grid(row=3, column=1, padx=10, pady=5)

        # Add Payment Button
        def add_payment():
            try:
                payment = Payment(
                    payment_id=payment_id_entry.get(),
                    amount=float(amount_entry.get()),
                    method=method_entry.get(),
                    status="pending",
                    payment_date=datetime.now(),
                    reservation_id=int(reservation_id_entry.get())
                )
                session.add(payment)
                session.commit()
                messagebox.showinfo("Success", "Payment added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add payment: {e}")

        tk.Button(scrollable_frame, text="Add Payment", command=add_payment).grid(row=4, column=0, columnspan=2, pady=10)
        return tab
    def add_promotion_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Promotion")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Promotion
        tk.Label(scrollable_frame, text="Promo ID:").grid(row=0, column=0, padx=10, pady=5)
        promo_id_entry = tk.Entry(scrollable_frame)
        promo_id_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Description:").grid(row=1, column=0, padx=10, pady=5)
        description_entry = tk.Entry(scrollable_frame)
        description_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Discount Percentage:").grid(row=2, column=0, padx=10, pady=5)
        discount_entry = tk.Entry(scrollable_frame)
        discount_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Start Date (YYYY-MM-DD):").grid(row=3, column=0, padx=10, pady=5)
        start_date_entry = tk.Entry(scrollable_frame)
        start_date_entry.grid(row=3, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="End Date (YYYY-MM-DD):").grid(row=4, column=0, padx=10, pady=5)
        end_date_entry = tk.Entry(scrollable_frame)
        end_date_entry.grid(row=4, column=1, padx=10, pady=5)

        # Add Promotion Button
        def add_promotion():
            try:
                promotion = Promotion(
                    promo_id=promo_id_entry.get(),
                    description=description_entry.get(),
                    discount_percentage=float(discount_entry.get()),
                    start_date=datetime.strptime(start_date_entry.get(), "%Y-%m-%d"),
                    end_date=datetime.strptime(end_date_entry.get(), "%Y-%m-%d")
                )
                session.add(promotion)
                session.commit()
                messagebox.showinfo("Success", "Promotion added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add promotion: {e}")

        tk.Button(scrollable_frame, text="Add Promotion", command=add_promotion).grid(row=5, column=0, columnspan=2, pady=10)
        return tab
    def add_luggage_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Luggage")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Luggage
        tk.Label(scrollable_frame, text="Luggage ID:").grid(row=0, column=0, padx=10, pady=5)
        luggage_id_entry = tk.Entry(scrollable_frame)
        luggage_id_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Passenger ID:").grid(row=1, column=0, padx=10, pady=5)
        passenger_id_entry = tk.Entry(scrollable_frame)
        passenger_id_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Weight:").grid(row=2, column=0, padx=10, pady=5)
        weight_entry = tk.Entry(scrollable_frame)
        weight_entry.grid(row=2, column=1, padx=10, pady=5)

        # Add Luggage Button
        def add_luggage():
            try:
                luggage = Luggage(
                    luggage_id=luggage_id_entry.get(),
                    passenger_id=int(passenger_id_entry.get()),
                    weight=float(weight_entry.get())
                )
                session.add(luggage)
                session.commit()
                messagebox.showinfo("Success", "Luggage added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add luggage: {e}")

        tk.Button(scrollable_frame, text="Add Luggage", command=add_luggage).grid(row=3, column=0, columnspan=2, pady=10)
        return tab
    def add_loyalty_program_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Loyalty Program")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for Loyalty Program
        tk.Label(scrollable_frame, text="Program Name:").grid(row=0, column=0, padx=10, pady=5)
        program_name_entry = tk.Entry(scrollable_frame)
        program_name_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Passenger ID:").grid(row=1, column=0, padx=10, pady=5)
        passenger_id_entry = tk.Entry(scrollable_frame)
        passenger_id_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Points:").grid(row=2, column=0, padx=10, pady=5)
        points_entry = tk.Entry(scrollable_frame)
        points_entry.grid(row=2, column=1, padx=10, pady=5)

        # Add Loyalty Program Button
        def add_loyalty_program():
            try:
                loyalty_program = Loyalty_program(
                    program_name=program_name_entry.get(),
                    passenger_id=int(passenger_id_entry.get()),
                    points=int(points_entry.get())
                )
                session.add(loyalty_program)
                session.commit()
                messagebox.showinfo("Success", "Loyalty Program added successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to add loyalty program: {e}")

        tk.Button(scrollable_frame, text="Add Loyalty Program", command=add_loyalty_program).grid(row=3, column=0, columnspan=2, pady=10)


        return tab

    def add_airport_image_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Airport Image")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Field for Airport Code
        tk.Label(scrollable_frame, text="Airport Code:").grid(row=0, column=0, padx=10, pady=5)
        airport_code_entry = tk.Entry(scrollable_frame)
        airport_code_entry.grid(row=0, column=1, padx=10, pady=5)

        # Display Area for Image
        image_label = tk.Label(scrollable_frame)  # Define the image_label here
        image_label.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

        # Function to Query Airport and Display Image
        def display_airport_image():
            try:
                # Query the airport by code
                airport_code = airport_code_entry.get()
                airport = session.query(Airport).filter_by(code=airport_code).first()

                if not airport:
                    messagebox.showerror("Error", f"No airport found with code {airport_code}.")
                    return

                # Get the location and construct the image filename
                location = airport.location
                image_filename = f"{location}.jpg"

                # Check if the image file exists
                if not os.path.exists(image_filename):
                    messagebox.showerror("Error", f"No image found for location: {location}.")
                    return

                # Open the image using Pillow
                img = Image.open(image_filename)

                # Resize the image to fit the display area (optional)
                img = img.resize((400, 300), Image.Resampling.LANCZOS)  # Resize to 400x300 pixels

                # Convert the image to a format compatible with Tkinter
                img_tk = ImageTk.PhotoImage(img)

                # Display the image
                image_label.config(image=img_tk)
                image_label.image = img_tk  # Keep a reference to avoid garbage collection

            except Exception as e:
                messagebox.showerror("Error", f"Failed to display image: {e}")

        # Button to Trigger the Display Function
        tk.Button(scrollable_frame, text="Show Image", command=display_airport_image).grid(row=1, column=0, columnspan=2, pady=10)
        return tab

#Tab for user class 
    def add_user_tab(self):
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="User Management")
        scrollable_frame = self.create_scrollable_frame(tab)

        # Fields for User
        tk.Label(scrollable_frame, text="Username:").grid(row=0, column=0, padx=10, pady=5)
        username_entry = tk.Entry(scrollable_frame)
        username_entry.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Email:").grid(row=1, column=0, padx=10, pady=5)
        email_entry = tk.Entry(scrollable_frame)
        email_entry.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Password:").grid(row=2, column=0, padx=10, pady=5)
        password_entry = tk.Entry(scrollable_frame, show="*")
        password_entry.grid(row=2, column=1, padx=10, pady=5)

        # Add User Button
        def add_user():
            try:
                User.create_user(session, username=username_entry.get(), email=email_entry.get(), password=password_entry.get())
                messagebox.showinfo("Success", "User created successfully!")
            except Exception as e:
                session.rollback()
                messagebox.showerror("Error", f"Failed to create user: {e}")

        tk.Button(scrollable_frame, text="Add User", command=add_user).grid(row=3, column=0, columnspan=2, pady=10)

        # Fields for Authentication
        tk.Label(scrollable_frame, text="Authenticate Username:").grid(row=4, column=0, padx=10, pady=5)
        auth_username_entry = tk.Entry(scrollable_frame)
        auth_username_entry.grid(row=4, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Authenticate Email:").grid(row=5, column=0, padx=10, pady=5)
        auth_email_entry = tk.Entry(scrollable_frame)
        auth_email_entry.grid(row=5, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Authenticate Password:").grid(row=6, column=0, padx=10, pady=5)
        auth_password_entry = tk.Entry(scrollable_frame, show="*")
        auth_password_entry.grid(row=6, column=1, padx=10, pady=5)

        # Authenticate User Button
        def authenticate_user():
            try:
                is_authenticated = User.authenticate_user(
                    session,
                    username=auth_username_entry.get(),
                    email=auth_email_entry.get(),
                    password=auth_password_entry.get()
                )
                if is_authenticated:
                    messagebox.showinfo("Success", "Authentication successful!")
                else:
                    messagebox.showerror("Error", "Authentication failed.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to authenticate user: {e}")

        tk.Button(scrollable_frame, text="Authenticate User", command=authenticate_user).grid(row=7, column=0, columnspan=2, pady=10)

        # Fields for Deactivation
        tk.Label(scrollable_frame, text="Deactivate Username:").grid(row=8, column=0, padx=10, pady=5)
        deactivate_username_entry = tk.Entry(scrollable_frame)
        deactivate_username_entry.grid(row=8, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Deactivate Email:").grid(row=9, column=0, padx=10, pady=5)
        deactivate_email_entry = tk.Entry(scrollable_frame)
        deactivate_email_entry.grid(row=9, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Deactivate Password:").grid(row=10, column=0, padx=10, pady=5)
        deactivate_password_entry = tk.Entry(scrollable_frame, show="*")
        deactivate_password_entry.grid(row=10, column=1, padx=10, pady=5)

        # Deactivate User Button
        def deactivate_user():
            try:
                User.deactivate_user(
                    session,
                    username=deactivate_username_entry.get(),
                    email=deactivate_email_entry.get(),
                    password=deactivate_password_entry.get()
                )
                messagebox.showinfo("Success", "User deactivated successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to deactivate user: {e}")

        tk.Button(scrollable_frame, text="Deactivate User", command=deactivate_user).grid(row=11, column=0, columnspan=2, pady=10)

        # Fields for Password Update
        tk.Label(scrollable_frame, text="Update Username:").grid(row=12, column=0, padx=10, pady=5)
        update_username_entry = tk.Entry(scrollable_frame)
        update_username_entry.grid(row=12, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Update Email:").grid(row=13, column=0, padx=10, pady=5)
        update_email_entry = tk.Entry(scrollable_frame)
        update_email_entry.grid(row=13, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="Old Password:").grid(row=14, column=0, padx=10, pady=5)
        old_password_entry = tk.Entry(scrollable_frame, show="*")
        old_password_entry.grid(row=14, column=1, padx=10, pady=5)

        tk.Label(scrollable_frame, text="New Password:").grid(row=15, column=0, padx=10, pady=5)
        new_password_entry = tk.Entry(scrollable_frame, show="*")
        new_password_entry.grid(row=15, column=1, padx=10, pady=5)

        # Update Password Button
        def update_password():
            try:
                User.update_password(
                    session,
                    username=update_username_entry.get(),
                    email=update_email_entry.get(),
                    old_password=old_password_entry.get(),
                    new_password=new_password_entry.get()
                )
                messagebox.showinfo("Success", "Password updated successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update password: {e}")

        tk.Button(scrollable_frame, text="Update Password", command=update_password).grid(row=16, column=0, columnspan=2, pady=10)

        return tab  # Ensure the tab object is returned


if __name__ == "__main__":
    import socket
    import threading
    import json

    # Server Configuration
    HOST = '127.0.0.1'  # Localhost
    PORT = 65432        # Port to listen on

    def handle_client_connection(client_socket):
        """
        Handle incoming client connections and process reservation details.
        """
        try:
            # Receive data from the client
            data = client_socket.recv(1024).decode('utf-8')
            reservation_details = json.loads(data)  # Parse the JSON data

            # Extract reservation details
            passenger_id = reservation_details['passenger_id']
            seat_number = reservation_details['seat_number']

            # Process the reservation
            reservation = Reservation(
                session=session,
                passenger_national_id=passenger_id,
                departure_country_code=reservation_details['departure_code'],
                destination_country_code=reservation_details['destination_code'],
                seat_number=seat_number
            )
            session.add(reservation)
            session.commit()

            # Send a success response to the client
            client_socket.sendall(b"Reservation created successfully!")
            print(f"Reservation created: {reservation}")

        except Exception as e:
            # Send an error response to the client
            client_socket.sendall(f"Error: {e}".encode('utf-8'))
            session.rollback()
            print(f"Error processing reservation: {e}")

        finally:
            client_socket.close()

    def start_server():
        """
        Start the socket server to handle client connections.
        """
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind((HOST, PORT))
        server_socket.listen(5)  # Allow up to 5 simultaneous connections
        print(f"Server listening on {HOST}:{PORT}")

        while True:
            client_socket, addr = server_socket.accept()
            print(f"Connection from {addr}")
            client_handler = threading.Thread(target=handle_client_connection, args=(client_socket,))
            client_handler.start()

    # Start the server in a separate thread
    server_thread = threading.Thread(target=start_server, daemon=True)
    server_thread.start()    
    app = FlightReservationApp()
    app.mainloop()